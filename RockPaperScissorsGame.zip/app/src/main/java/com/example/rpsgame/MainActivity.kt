package com.example.rpsgame

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val resultText: TextView = findViewById(R.id.resultText)
        val userChoiceText: TextView = findViewById(R.id.userChoiceText)
        val computerChoiceText: TextView = findViewById(R.id.computerChoiceText)

        val rockButton: Button = findViewById(R.id.rockButton)
        val paperButton: Button = findViewById(R.id.paperButton)
        val scissorsButton: Button = findViewById(R.id.scissorsButton)

        rockButton.setOnClickListener { playGame("Rock", resultText, userChoiceText, computerChoiceText) }
        paperButton.setOnClickListener { playGame("Paper", resultText, userChoiceText, computerChoiceText) }
        scissorsButton.setOnClickListener { playGame("Scissors", resultText, userChoiceText, computerChoiceText) }
    }

    private fun playGame(userChoice: String, resultText: TextView, userChoiceText: TextView, computerChoiceText: TextView) {
        val choices = listOf("Rock", "Paper", "Scissors")
        val computerChoice = choices[Random.nextInt(choices.size)]

        userChoiceText.text = "You chose: $userChoice"
        computerChoiceText.text = "Computer chose: $computerChoice"

        val result = when {
            userChoice == computerChoice -> "It's a Tie!"
            userChoice == "Rock" && computerChoice == "Scissors" -> "You Win! 🎉"
            userChoice == "Paper" && computerChoice == "Rock" -> "You Win! 🎉"
            userChoice == "Scissors" && computerChoice == "Paper" -> "You Win! 🎉"
            else -> "You Lose! 😢"
        }

        resultText.text = "Result: $result"
    }
}